export interface VitalSigns {
  heartRate: number;
  systolicBP: number;
  diastolicBP: number;
  isResponsive: boolean;
}

export interface Coordinates {
  latitude: number;
  longitude: number;
}

export interface EmergencyContact {
  name: string;
  relationship: string;
  phone: string;
}

export interface EmergencyStatus {
  isCritical: boolean;
  statusMessage: string;
  trigger: string | null;
}

export interface EmergencyResponseData {
  hospitalName: string;
  hospitalAddress: string;
  directions: string;
  mapLink?: string;
}

export interface MedicalHistory {
  name: string;
  age: number;
  conditions: string[];
  allergies: string[];
  medications: string[];
}
